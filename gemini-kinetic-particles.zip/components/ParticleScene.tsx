import React, { useRef, useMemo, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { ParticleState, ParticleShape } from '../types';

interface ParticleSceneProps {
  targetState: ParticleState;
}

const COUNT = 4000;
const DUMMY = new THREE.Object3D();
const POSITIONS = new Float32Array(COUNT * 3);
const COLORS = new Float32Array(COUNT * 3);

// Helper to get point on specific shapes
const getShapePosition = (i: number, count: number, shape: ParticleShape, expansion: number) => {
  const t = (i / count) * Math.PI * 2;
  const t2 = (i / count) * Math.PI * 10; // More frequent for loops
  const r = Math.random();
  const phi = Math.acos(2 * Math.random() - 1);
  const theta = Math.sqrt(count * Math.PI) * phi;
  
  let x = 0, y = 0, z = 0;

  switch (shape) {
    case 'heart':
      // 3D Heart Approximation
      // x = 16sin^3(t)
      // y = 13cos(t) - 5cos(2t) - 2cos(3t) - cos(4t)
      // We need to distribute points on surface. Using a rejection sampling or simple parametric.
      // Let's use a simpler parametric distribution for visuals.
      const h_phi = (i / count) * Math.PI * 2;
      const h_theta = (i % 100) / 100 * Math.PI;
      // Very rough heart blob
      const hx = 16 * Math.pow(Math.sin(h_phi), 3);
      const hy = 13 * Math.cos(h_phi) - 5 * Math.cos(2 * h_phi) - 2 * Math.cos(3 * h_phi) - Math.cos(4 * h_phi);
      // Add depth
      const hz = (Math.random() - 0.5) * 5; 
      x = hx * 0.1;
      y = hy * 0.1;
      z = hz;
      break;

    case 'flower':
      const f_u = (i / count) * Math.PI * 2;
      const f_r = 2 + Math.sin(7 * f_u); // 7 petals
      x = f_r * Math.cos(f_u);
      y = f_r * Math.sin(f_u);
      z = (Math.random() - 0.5) * 2; // Flat-ish
      break;

    case 'saturn':
      if (i < count * 0.7) {
         // Planet Body
         const s_r = 1.5;
         x = s_r * Math.sin(phi) * Math.cos(theta);
         y = s_r * Math.sin(phi) * Math.sin(theta);
         z = s_r * Math.cos(phi);
      } else {
         // Ring
         const ring_r = 2.5 + Math.random() * 1.5;
         const ring_theta = Math.random() * Math.PI * 2;
         x = ring_r * Math.cos(ring_theta);
         z = ring_r * Math.sin(ring_theta);
         y = (Math.random() - 0.5) * 0.2; // Thin ring
      }
      break;

    case 'helix':
      const he_t = i * 0.1;
      x = Math.cos(he_t);
      z = Math.sin(he_t);
      y = (i / count) * 10 - 5;
      break;

    case 'fireworks':
        // Explosion from center
        const fw_theta = Math.random() * Math.PI * 2;
        const fw_phi = Math.acos(2 * Math.random() - 1);
        const fw_r = Math.pow(Math.random(), 0.3) * 3; // Cluster near outside
        x = fw_r * Math.sin(fw_phi) * Math.cos(fw_theta);
        y = fw_r * Math.sin(fw_phi) * Math.sin(fw_theta);
        z = fw_r * Math.cos(fw_phi);
        break;

    case 'sphere':
    default:
      const s_rad = 2;
      x = s_rad * Math.sin(phi) * Math.cos(theta);
      y = s_rad * Math.sin(phi) * Math.sin(theta);
      z = s_rad * Math.cos(phi);
      break;
  }

  return new THREE.Vector3(x * expansion, y * expansion, z * expansion);
};

const getColor = (i: number, palette: string) => {
  const c = new THREE.Color();
  const r = Math.random();
  switch (palette) {
    case 'warm':
      c.setHSL(0.0 + r * 0.15, 0.9, 0.6); // Red to Orange
      break;
    case 'cool':
      c.setHSL(0.5 + r * 0.2, 0.8, 0.6); // Blue to Cyan
      break;
    case 'neon':
      c.setHSL(Math.random(), 1.0, 0.5); // All saturated
      break;
    case 'rainbow':
    default:
      c.setHSL(i / COUNT, 0.8, 0.5);
      break;
  }
  return c;
};

export const ParticleScene: React.FC<ParticleSceneProps> = ({ targetState }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const { shape, expansion, colorPalette, speed, rotationSpeed } = targetState;

  // Current interpolated state
  const currentExpansion = useRef(expansion);
  const currentRotation = useRef(0);

  // Memoize random offsets for animation so they are stable
  const offsets = useMemo(() => {
     const arr = new Float32Array(COUNT);
     for(let i=0; i<COUNT; i++) arr[i] = Math.random();
     return arr;
  }, []);

  useFrame((state, delta) => {
    if (!meshRef.current) return;

    // Smooth lerp for parameters
    currentExpansion.current = THREE.MathUtils.lerp(currentExpansion.current, expansion, delta * 2);
    currentRotation.current += delta * rotationSpeed * 0.5;

    meshRef.current.rotation.y = currentRotation.current;
    
    // Animate Colors (Update slowly or only on palette change? Realtime is expensive)
    // For performance, we'll just set colors when palette changes effectively by re-running logic if needed
    // But doing it every frame is heavy. Let's do a trick: 
    // We compute position every frame to animate the transition between shapes.
    
    const time = state.clock.getElapsedTime() * speed;

    for (let i = 0; i < COUNT; i++) {
        // Calculate Target Position based on current shape
        const pos = getShapePosition(i, COUNT, shape, currentExpansion.current);
        
        // Add some noise/movement
        pos.x += Math.sin(time + offsets[i] * 10) * 0.1;
        pos.y += Math.cos(time + offsets[i] * 10) * 0.1;
        pos.z += Math.sin(time + offsets[i] * 5) * 0.1;

        DUMMY.position.copy(pos);
        
        // Scale pulse
        const scale = 1 + Math.sin(time * 2 + offsets[i] * 5) * 0.3;
        DUMMY.scale.set(scale * 0.05, scale * 0.05, scale * 0.05);

        DUMMY.updateMatrix();
        meshRef.current.setMatrixAt(i, DUMMY.matrix);
        
        // Dynamic Color Updates
        if (i % 10 === 0) { // Optimization: only update colors sometimes or if needed.
             // Actually, instancedMesh colors are static unless updated. 
             // Let's handle color update in a useEffect or slowly blend.
             // For this demo, let's keep color static per palette choice to save FPS, 
             // but we need to re-apply if palette changes.
        }
    }
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  // Effect to update colors when palette changes
  useEffect(() => {
      if(!meshRef.current) return;
      for (let i = 0; i < COUNT; i++) {
          const c = getColor(i, colorPalette);
          meshRef.current.setColorAt(i, c);
      }
      meshRef.current.instanceColor!.needsUpdate = true;
  }, [colorPalette]);

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, COUNT]}>
      <sphereGeometry args={[1, 16, 16]} />
      <meshStandardMaterial 
        toneMapped={false} 
        emissiveIntensity={2}
        color="#ffffff"
        roughness={0.1}
        metalness={0.8}
      />
    </instancedMesh>
  );
};
