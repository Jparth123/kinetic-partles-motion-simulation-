export type ParticleShape = 'sphere' | 'heart' | 'flower' | 'saturn' | 'fireworks' | 'helix';

export interface ParticleState {
  shape: ParticleShape;
  expansion: number; // 0.1 to 3.0
  colorPalette: string; // 'neon', 'warm', 'cool', 'rainbow'
  speed: number; // 0.1 to 2.0
  rotationSpeed: number;
}

export interface LiveConnectionState {
  isConnected: boolean;
  isStreaming: boolean;
  error: string | null;
}
