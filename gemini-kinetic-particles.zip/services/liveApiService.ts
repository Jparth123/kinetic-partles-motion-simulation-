import { GoogleGenAI, LiveServerMessage, Modality, Type, FunctionDeclaration } from '@google/genai';
import { ParticleState, ParticleShape } from '../types';

export const MODEL_NAME = 'gemini-2.5-flash-native-audio-preview-12-2025';

const updateParticlesTool: FunctionDeclaration = {
  name: 'updateParticles',
  parameters: {
    type: Type.OBJECT,
    description: 'Update the visual state of the particle system based on user hand gestures.',
    properties: {
      shape: {
        type: Type.STRING,
        enum: ['sphere', 'heart', 'flower', 'saturn', 'fireworks', 'helix'],
        description: 'The geometric shape of the particle swarm.',
      },
      expansion: {
        type: Type.NUMBER,
        description: 'The expansion factor of the particles (0.1 = contracted/fist, 2.0 = expanded/open hand).',
      },
      colorPalette: {
        type: Type.STRING,
        enum: ['neon', 'warm', 'cool', 'rainbow'],
        description: 'The color theme of the particles.',
      },
      speed: {
        type: Type.NUMBER,
        description: 'Animation speed multiplier.',
      },
      rotationSpeed: {
        type: Type.NUMBER,
        description: 'Rotation speed of the entire system.',
      }
    },
    required: [], // All optional to allow partial updates
  },
};

export class LiveApiService {
  private client: GoogleGenAI;
  private session: any = null;
  private onStateUpdate: (update: Partial<ParticleState>) => void;
  private onError: (error: string) => void;

  constructor(onStateUpdate: (update: Partial<ParticleState>) => void, onError: (error: string) => void) {
    this.client = new GoogleGenAI({ apiKey: process.env.API_KEY });
    this.onStateUpdate = onStateUpdate;
    this.onError = onError;
  }

  async connect() {
    try {
      this.session = await this.client.live.connect({
        model: MODEL_NAME,
        callbacks: {
          onopen: () => console.log('Gemini Live API Connected'),
          onmessage: (msg: LiveServerMessage) => this.handleMessage(msg),
          onclose: () => console.log('Gemini Live API Closed'),
          onerror: (e: ErrorEvent) => {
             console.error('Gemini API Error:', e);
             this.onError('Connection error occurred.');
          },
        },
        config: {
          responseModalities: [Modality.AUDIO], // We must accept audio, even if we mainly want tool calls
          tools: [{ functionDeclarations: [updateParticlesTool] }],
          systemInstruction: `
            You are a visual controller for a 3D particle system. 
            Analyze the video stream of the user's hands and face to control the art.
            
            Strictly follow these gesture mappings:
            1. **Open Hand / Palm**: Set 'expansion' to high (1.5 - 2.5). 
            2. **Closed Fist**: Set 'expansion' to low (0.2 - 0.5).
            3. **Peace Sign (V)**: Switch 'shape' to 'heart'.
            4. **Thumb Up**: Switch 'shape' to 'fireworks' and high speed.
            5. **Okay Sign (👌)**: Switch 'shape' to 'saturn'.
            6. **Index Finger Pointing**: Cycle 'colorPalette' (e.g., random choice of neon, warm, cool).
            7. **Waving Hand**: Switch 'shape' to 'helix' and increase 'rotationSpeed'.
            8. **Two Hands Open**: Switch 'shape' to 'flower'.

            Be responsive. When you see a gesture, IMMEDIATELY call the 'updateParticles' tool with the new parameters.
            You do not need to speak much, just acknowledge changes briefly like "Expanding", "Heart mode", etc.
          `,
        },
      });
    } catch (error: any) {
      this.onError(error.message || 'Failed to connect');
    }
  }

  private handleMessage(message: LiveServerMessage) {
    // Handle Tool Calls (The core control mechanism)
    if (message.toolCall) {
      for (const fc of message.toolCall.functionCalls) {
        if (fc.name === 'updateParticles') {
          console.log('Tool Call Received:', fc.args);
          this.onStateUpdate(fc.args as Partial<ParticleState>);
          
          // Respond to the tool call so the model knows it succeeded
          this.session.sendToolResponse({
            functionResponses: {
              id: fc.id,
              name: fc.name,
              response: { result: 'ok' },
            }
          });
        }
      }
    }
  }

  async sendVideoFrame(base64Image: string) {
    if (!this.session) return;
    try {
        this.session.sendRealtimeInput({
            media: {
                mimeType: 'image/jpeg',
                data: base64Image
            }
        });
    } catch (e) {
        console.error("Error sending frame:", e);
    }
  }

  async disconnect() {
    if (this.session) {
      // live.connect doesn't expose a clean close method on the promise result in all versions, 
      // but if the SDK supports it, we should close. 
      // Current SDK usage suggests just stopping sending and letting it timeout or reload.
      // Ideally: this.session.close();
      this.session = null;
    }
  }
}

export const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, _) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      resolve(result.split(',')[1]);
    };
    reader.readAsDataURL(blob);
  });
};
